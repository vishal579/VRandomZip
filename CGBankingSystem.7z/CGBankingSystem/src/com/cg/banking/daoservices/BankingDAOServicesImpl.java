package com.cg.banking.daoservices;

import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	private static Customer[] customerList=new Customer[10];
	private static int CUSTOMER_ID_COUNTER=1;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static int ACCOUNT_NO_COUNTER=8000001;
	private static int PINNUMBER=8000;
	private static Random random=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		if(CUSTOMER_IDX_COUNTER>0.7*(customerList.length)){
		Customer[] tempList=new Customer[customerList.length+10];
		System.arraycopy(customerList, 0, tempList, 0, customerList.length);
		customerList=tempList;
		}
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
			if(customerList[i].getAccountIdxCounter()>0.7*(customerList[i].getAccounts().length)){
				Account[] tempList=new Account[customerList[i].getAccounts().length+10];
				System.arraycopy(customerList[i].getAccounts(), 0, tempList, 0, customerList[i].getAccounts().length);
				customerList[i].setAccounts(tempList);
			}	
				account.setAccountNo(ACCOUNT_NO_COUNTER++);
				customerList[i].getAccounts()[customerList[i].getAccountIdxCounter()]=account;
				customerList[i].setAccountIdxCounter(customerList[i].getAccountIdxCounter()+1);
				return account.getAccountNo();
			}
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j]==account)
						customerList[i].getAccounts()[j]=account;
				return true;
			}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j]==account){
						customerList[i].getAccounts()[j].setPinNumber(random.nextInt(10000));
						return customerList[i].getAccounts()[j].getPinNumber();
					}
			}
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo)==null)
			return false;
		if(getAccount(customerId, accountNo).getTransactionIdxCounter()<0.7*(getAccount(customerId, accountNo).getTransactions().length)){
			Transaction[] tempList=new Transaction[getAccount(customerId, accountNo).getTransactions().length+10];
			System.arraycopy(getAccount(customerId, accountNo).getTransactions(), 0, tempList, 0, getAccount(customerId, accountNo).getTransactions().length);
			getAccount(customerId, accountNo).setTransactions(tempList);
		}
		transaction.setTransactionId(getAccount(customerId, accountNo).getTransactionIdCounter());
		getAccount(customerId, accountNo).setTransactionIdCounter(getAccount(customerId, accountNo).getTransactionIdCounter()+1);
		getAccount(customerId, accountNo).getTransactions()[getAccount(customerId, accountNo).getTransactionIdxCounter()]=transaction;
		getAccount(customerId, accountNo).setTransactionIdxCounter(getAccount(customerId, accountNo).getTransactionIdxCounter()+1);
		return true;	
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()){ 
				customerList[i]=null;
				int j;
				for(j=i;j<customerList.length&&customerList[j+1]!=null;j++)
					customerList[j]=customerList[j+1];
				CUSTOMER_IDX_COUNTER=j;
				customerList[j]=null;
				return true;
				}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		if(getCustomer(customerId)==null)
			return false;
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++)
			if(getCustomer(customerId).getAccounts()[i]!=null&&getCustomer(customerId).getAccounts()[i].getAccountNo()==accountNo){
				getCustomer(customerId).getAccounts()[i]=null;
				int j;
				for(j=i;j<getCustomer(customerId).getAccounts().length&&getCustomer(customerId).getAccounts()[j+1]!=null;j++)
					getCustomer(customerId).getAccounts()[j]=getCustomer(customerId).getAccounts()[j+1];
				getCustomer(customerId).setAccountIdxCounter(j);
				getCustomer(customerId).getAccounts()[j]=null;
				return true;
				}
		return false;		
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerList[i].getCustomerId()==customerId)
				return customerList[i];
		
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerList[i].getCustomerId()==customerId)
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j].getAccountNo()==accountNo)
						return customerList[i].getAccounts()[j];
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		
		return customerList;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		
		return getCustomer(customerId).getAccounts();
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		
		return getAccount(customerId, accountNo).getTransactions();
	}

}
