package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.springframework.jdbc.core.RowMapper;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.mysql.jdbc.interceptors.SessionAssociationInterceptor;
@Component(value="daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	public PayrollDAOServicesImpl() {

	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public int insertAssociate(Associate associate) {
		//session = this.sessionFactory.openSession();
		return (int) sessionFactory.openSession().save(associate);
	}


	@Override
	public boolean updateAssociate(Associate associate) {
		session = this.sessionFactory.openSession();
		if(associate!=null){
		transaction=session.beginTransaction();
		session.update(associate);
		transaction.commit();
		return true;
		}
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateId) {
		session = this.sessionFactory.openSession();
		Associate associate=getAssociate(associateId);
		
		if(associate!=null){
			transaction=session.beginTransaction();
			session.delete(associate);
			transaction.commit();
			return true;
		}
		return false;
		/* String query = "delete from Associate where associateId = "+associateId;
		    Session session= sessionFactory.openSession();
		    session.createQuery(query);
			return true;*/
	}

	@Override
	public Associate getAssociate(int associateId) {
		return (Associate) sessionFactory.openSession().get(Associate.class, associateId);
	}


	@Override
	public List<Associate> getAssociates() {

		List<Associate> associateList = sessionFactory.openSession().createQuery("from Associate").list();
		return associateList;
	}

}



















/*@Override
	public int insertAssociate(Associate associate) {

		return (int) sessionFactory.openSession().save(associate);
	}


	@Override
	public boolean updateAssociate(Associate associate) {
		sessionFactory.openSession().update(associate);
		
		return true;
	}
	@Override
	public boolean deleteAssociate(int associateId) {
		Session session = this.sessionFactory.openSession();
		Associate associate=getAssociate(associateId);
		
		if(associate!=null){
			
			session.delete(associate);
			
			return true;
		}
		return false;
		/* String query = "delete from Associate where associateId = "+associateId;
		    Session session= sessionFactory.openSession();
		    session.createQuery(query);
			return true;
	}

	@Override
	public Associate getAssociate(int associateId) {
		return (Associate) sessionFactory.openSession().get(Associate.class, associateId);
	}


	@Override
	public List<Associate> getAssociates() {

		List<Associate> associateList = sessionFactory.openSession().createQuery("from Associate").list();
		return associateList;
	}*/