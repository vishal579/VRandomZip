package com.cg.inheritance.beans;

public abstract class Employee {
	private int employeeId,basicSalary,totalSalary;
	private String firstName,lastName;
	public Employee() {
		super();
	}
	public Employee(int employeeId, String firstName, String lastName) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public Employee(int employeeId, int basicSalary, String firstName, String lastName) {
		super();
		this.employeeId = employeeId;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public final int getEmployeeId() {
		return employeeId;
	}
	public final  void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public final int getBasicSalary() {
		return basicSalary;
	}
	public final void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public final int getTotalSalary() {
		return totalSalary;
	}
	public final void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	public final String getFirstName() {
		return firstName;
	}
	public final void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public final String getLastName() {
		return lastName;
	}
	public final void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public abstract void calculateSalary();
	
}
