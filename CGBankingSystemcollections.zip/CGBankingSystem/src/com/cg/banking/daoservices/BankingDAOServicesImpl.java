package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	private static HashMap<Integer, Customer> customerMap=new HashMap<>();
	private static int CUSTOMER_ID_COUNTER=1;
	//private static int CUSTOMER_IDX_COUNTER=0;
	private static long ACCOUNT_NO_COUNTER=8000001;
	private static Random random=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER);
		customerMap.put(CUSTOMER_ID_COUNTER++, customer);
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(ACCOUNT_NO_COUNTER);
		customerMap.get(customerId).getAccountMap().put(ACCOUNT_NO_COUNTER++, account);
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		if(customerMap.get(customerId).getAccountMap().containsKey(account.getAccountNo())==true){
		customerMap.get(customerId).getAccountMap().put(ACCOUNT_NO_COUNTER, account);
		return true;
		}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		if(customerMap.get(customerId).getAccountMap().containsKey(account.getAccountNo())==true){
			account.setPinNumber(random.nextInt(10000));
			return customerMap.get(customerId).getAccountMap().get(account.getAccountNo()).getPinNumber();
		}	
		return 0;	
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo)!=null){
			getCustomer(customerId).getAccountMap().get(accountNo).getTransactionMap().put((getAccount(customerId, accountNo).getTransactionIdCounter()), transaction);
			transaction.setTransactionId(getAccount(customerId, accountNo).getTransactionIdCounter()+1);
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		if(getCustomer(customerId)!=null){
		customerMap.remove(customerId);
		return true;
		}
		else
			return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		if(getCustomer(customerId)!=null){
			customerMap.get(customerId).getAccountMap().remove(accountNo);
			return true;
		}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customerMap.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		if(getCustomer(customerId)!=null)
			return customerMap.get(customerId).getAccountMap().get(accountNo);
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		
		return new ArrayList(customerMap.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		
		return new ArrayList(customerMap.get(customerId).getAccountMap().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		
		return new ArrayList(customerMap.get(customerId).getAccountMap().get(accountNo).getTransactionMap().values());
	}



}
