package com.cg.banking.main;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		int k=0;
		do {

			/*System.out.println("1.  Register as a Customer"+"\n"+"2.  Create Account"+"\n"+"3.  Balance Enquiry"+"\n"+"4.  Deposit"+"\n"+"5.  Withdraw"+"\n"+"6.  Fund Transfer"+"\n"+"7.  About You"+"\n"+"8.  Account MiniStatement"+"\n"+"9.  Delete Account"+" \n"+"10. Change Pin number"+" \n"+
					"11. Exit"+"\n"+"\n"+"Enter Your Choice");*/
			System.out.println("1.  Register as a Customer");
			System.out.println("2.  Create Account");
			System.out.println("3.  Balance Enquiry");
			System.out.println("4.  Deposit");
			System.out.println("5.  Withdraw");
			System.out.println("6.  Fund Transfer");
			System.out.println("7.  About You");
			System.out.println("8.  Account MiniStatement");
			System.out.println("9.  Delete Account");
			System.out.println("10. Change Pin number");
			System.out.println("11. Exit"+"\n"+"\n"+"Enter Your Choice");
			Scanner scanner=new Scanner(System.in);
			k=scanner.nextInt();
			BankingServicesImpl bankingServicesImpl=new BankingServicesImpl();
			try{
			switch (k) {
						
			case 1:
				String firstName, lastName, emailId, panCard, localAddressCity, localAddressState, homeAddressCity, homeAddressState;
				int localAddressPinCode, homeAddressPinCode,pinNumber;
				String accountType;
				//long accountNo;
				float initBalance,amount;

				System.out.println("Please Enter Your Details:");
				System.out.println("Enter FirstName ");
				firstName=scanner.next();
				System.out.println("Enter LastName ");
				lastName=scanner.next();
				System.out.println("Enter emailId  ");
				emailId=scanner.next();
				System.out.println("Enter Pancard ");
				panCard=scanner.next();
				System.out.println("Enter localAddressCity");
				localAddressCity=scanner.next();
				System.out.println("Enter localAddressState  ");
				localAddressState=scanner.next();
				System.out.println("Enter localAddressPinCode  ");
				localAddressPinCode=scanner.nextInt();
				System.out.println("Enter homeAddressCity");
				homeAddressCity=scanner.next();
				System.out.println("Enter homeAddressState ");
				homeAddressState=scanner.next();
				System.out.println("Enter homeAddressPinCode  ");
				homeAddressPinCode=scanner.nextInt();
			
				int customerId=bankingServicesImpl.acceptCustomerDetails(firstName, lastName, emailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
				
				System.out.println("Super well done customer..Your customerId is"+customerId);
				
				    
				break;
			case 2:
				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				System.out.println("Enter AccountType");
				accountType=scanner.next();
				System.out.println("Enter InitBalance");
				initBalance=scanner.nextFloat();

				long accountNo=bankingServicesImpl.openAccount(customerId, accountType, initBalance);
				System.out.println(accountNo);
				int pinNo=bankingServicesImpl.generateNewPin(customerId, accountNo);
				System.out.println("Account Balance is"+initBalance+"in your "+accountType+"account");

				System.out.println("Thank You"+" "+"Your account number is"+" "+accountNo+"  "+"your pin number"+pinNo);
				System.out.println("PinNo evariki cheppoddu"+"   "+bankingServicesImpl.getCustomerDetails(customerId).getCustomerId());
				break;	
			case 3:
				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				System.out.println("Enter AccountNo");
				accountNo=scanner.nextInt();
				
				System.out.println("Your Account Balance is"+" "+bankingServicesImpl.getAccountDetails(customerId, accountNo).getAccountBalance());
				break;
			case 4:
				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				System.out.println("Enter AccountNo");
				accountNo=scanner.nextInt();
				System.out.println("Enter Amount to be deposited");
				amount=scanner.nextFloat();
				
				System.out.println("Your update Account Balance is"+" "+bankingServicesImpl.depositAmount(customerId, accountNo, amount));
				break;
			case 5:
				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				System.out.println("Enter AccountNo");
				accountNo=scanner.nextInt();
				System.out.println("Enter Amount to be deposited");
				amount=scanner.nextFloat();
				System.out.println("Enter your pin number");
				pinNumber=scanner.nextInt();
				if(bankingServicesImpl.withdrawAmount(customerId, accountNo, amount, pinNumber)!=0)
					System.out.println("Your updated Account Balance is"+" "+bankingServicesImpl.getAccountDetails(customerId, accountNo).getAccountBalance());
				break;
			case 6:
				System.out.println("Enter CustomerId");
				int customerIdFrom=scanner.nextInt();
				System.out.println("Enter AccountNo");
				int accountNoFrom=scanner.nextInt();
				System.out.println("Enter CustomerIdTo");
				int customerIdTo=scanner.nextInt();
				System.out.println("Enter AccountNoTo");
				int accountNoTo=scanner.nextInt();
				
				
				System.out.println("Enter Amount to be transferred");
				float transferAmount=scanner.nextFloat();
				
				System.out.println("Enter your pin number");
				pinNumber=scanner.nextInt();
				
				if(bankingServicesImpl.fundTransfer(customerIdTo, accountNoTo, customerIdFrom, accountNoFrom, transferAmount, pinNumber)){
				System.out.println("Fund transfer of amount"+" "+transferAmount+ " "+"to account number"+" "+accountNoTo +" "+"done successfully");
				System.out.println("Your updated Account Balance is"+" "+bankingServicesImpl.getAccountDetails(customerIdFrom, accountNoFrom).getAccountBalance());
				}
				else
					System.out.println("Fund transfer of amount"+" "+transferAmount+ " "+"to account number"+" "+accountNoTo +" "+"failed");
				break;
			case 7:
				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				
				System.out.println(bankingServicesImpl.getCustomerDetails(customerId).toString());
				break;
			case 8:
				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				System.out.println("Enter AccountNo");
				accountNo=scanner.nextInt();
				System.out.println("All transactions done till date"+" "+bankingServicesImpl.getAccountDetails(customerId, accountNo));
				//System.out.println("All transactions done till date"+" "+bankingServicesImpl.getAccountDetails(customerId, accountNo).getTransactionMap().toString());
				break;
			case 9:

				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				System.out.println("Enter AccountNo");
				accountNo=scanner.nextInt();
				
				if(bankingServicesImpl.deleteAccount(customerId, accountNo))
					System.out.println("Account successfully deleted");
				else
					System.out.println("Account couldn't be deleted");
				break;
			case 10:
				System.out.println("Enter CustomerId");
				customerId=scanner.nextInt();
				System.out.println("Enter AccountNo");
				accountNo=scanner.nextInt();
				System.out.println("Enter your old pin number");
				pinNumber=scanner.nextInt();
				System.out.println("Enter your new pin number");
				int newPinNumber=scanner.nextInt();
				
				if(bankingServicesImpl.changeAccountPin(customerId, accountNo, pinNumber, newPinNumber))
					System.out.println("A new pin number successfully created to your account");
				else
					System.out.println("A new pin number failed created to your account");
				break;
			case 11:
				System.out.println("Thank You");
			default:
				break;
			}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		
		}while (k!=11);
		
		}
}
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		BankingServicesImpl bankingServicesImpl=new BankingServicesImpl();
		int customerId=bankingServicesImpl.acceptCustomerDetails("Vishal", "Sai", "bank@gmail.com", "abc1000", "HYD", "TG", 500014, "HYDERABAD", "TELANGANA", 500001);
	
		Customer customer=bankingServicesImpl.getCustomerDetails(customerId);
		long accountNo=bankingServicesImpl.openAccount(customerId, "Savings", 800000f);
		
		int pin=bankingServicesImpl.generateNewPin(customerId, accountNo);
		float da=bankingServicesImpl.depositAmount(customerId, accountNo, 10000);
		float da2=bankingServicesImpl.depositAmount(customerId, accountNo, 20000);
		float da4=bankingServicesImpl.depositAmount(customerId, accountNo, 40000);
		float wa=bankingServicesImpl.withdrawAmount(customerId, accountNo, 15000, customer.getAccounts()[0].getPinNumber());
		System.out.println(customer.getAccounts()[0].getPinNumber());
		System.out.println(customer.getAccounts()[0].getTransactions()[3].getTransactionType());
		//boolean b=bankingServicesImpl.changeAccountPin(customerId, accountNo, customer.getAccounts()[0].getPinNumber(), 8000);
		//float wa=bankingServicesImpl.withdrawAmount(customerId, accountNo, 15000, 0);
		//System.out.println(wa+" "+customer.getAccounts()[0].getPinNumber()+" "+bankingServicesImpl.getAccountDetails(customerId, accountNo).getStatus());
		/*System.out.println(customer.getAccounts()[0].getTransactions()[0].getTransactionId()+" "+customer.getAccounts()[0].getTransactions()[0].getAmount()+" " +customer.getAccounts()[0].getTransactions()[1].getTransactionId()+" "+customer.getAccounts()[0].getTransactions()[1].getAmount()+" "+customer.getAccounts()[0].getTransactions()[2].getTransactionId()+" "+customer.getAccounts()[0].getTransactions()[2].getAmount()+" "+customer.getAccounts()[0].getTransactions()[3].getTransactionId()+" "+customer.getAccounts()[0].getTransactions()[3].getAmount());
		System.out.println(customer.getAccounts()[0].getAccountBalance());
		//System.out.println(customerId+" "+accountNo);
		boolean a=bankingServicesImpl.fundTransfer(6, 12345, customerId, accountNo, 15000, customer.getAccounts()[0].getPinNumber());
		float da121=bankingServicesImpl.depositAmount(customerId, accountNo, 10000);
		float da111=bankingServicesImpl.depositAmount(customerId, accountNo, 20000);
		float da112=bankingServicesImpl.depositAmount(customerId, accountNo, 30000);
		System.out.println(a);
		System.out.println(customer.getAccounts()[0].getAccountBalance());
		//float da5=bankingServicesImpl.depositAmount(customerId, accountNo, 10000);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//System.out.println(accountNo+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[0].getTransactionIdxCounter()+" "+customer.getAccounts()[0].getTransactions()[0].getAmount()+" "+da4);
		long accountNo1=bankingServicesImpl.openAccount(customerId, "Salary", 900000f);
		
		System.out.println(accountNo1+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[1].getTransactionIdxCounter());
		int pin1=bankingServicesImpl.generateNewPin(customerId, accountNo1);
		float da11=bankingServicesImpl.depositAmount(customerId, accountNo1, 20000);
		float da12=bankingServicesImpl.depositAmount(customerId, accountNo1, 30000);
		System.out.println(accountNo1+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[1].getTransactionIdxCounter());
		System.out.println(customer.getAccounts()[1].getPinNumber());
		System.out.println(customer.getAccounts()[1].getAccountBalance());
		
        long accountNo2=bankingServicesImpl.openAccount(customerId, "current", 1000000f);
		System.out.println(accountNo2+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[2].getTransactionIdxCounter());
		int pin31=bankingServicesImpl.generateNewPin(customerId, accountNo2);
		float da31=bankingServicesImpl.depositAmount(customerId, accountNo2, 60000);
		float da14=bankingServicesImpl.depositAmount(customerId, accountNo2, 60000);
		System.out.println(accountNo2+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[2].getTransactionIdxCounter());
		System.out.println(customer.getAccounts()[2].getPinNumber());
		System.out.println(customer.getAccounts()[2].getAccountBalance());
		
		long accountNo3=bankingServicesImpl.openAccount(customerId, "current", 1000000f);
		System.out.println(accountNo3+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[3].getTransactionIdxCounter());
		int pin33=bankingServicesImpl.generateNewPin(customerId, accountNo3);
		float da33=bankingServicesImpl.depositAmount(customerId, accountNo3, 60000);
		float da13=bankingServicesImpl.depositAmount(customerId, accountNo3, 60000);
		System.out.println(accountNo3+" "+customer.getAccountIdxCounter()+" "+customer.getAccounts()[3].getTransactionIdxCounter());
		System.out.println(customer.getAccounts()[3].getPinNumber());
		System.out.println(customer.getAccounts()[3].getAccountBalance());
		
		//System.out.println(customer.getAccounts()[0].getAccountNo()+" "+customer.getAccounts()[0].getAccountNo());
		//System.out.println(customerId+" "+accountNo+" "+pin+ " "+da+" "+customer.getAccountIdxCounter());
		//System.out.println(customerId+" "+accountNo1+" "+pin1+ " "+da1+" "+customer.getAccountIdxCounter());
		
		long accountNo1=bankingServicesImpl.openAccount(customerId, "Salary", 900000f);
		
		int pin1=bankingServicesImpl.generateNewPin(customerId, accountNo1);
		float da1=bankingServicesImpl.depositAmount(customerId, accountNo1, 50000);
		System.out.println(bankingServicesImpl.getCustomerDetails(customerId).toString());*/
		//System.out.println(bankingServicesImpl.getCustomerDetails(customerId).getAccountIdxCounter());
		//boolean b=bankingServicesImpl.deleteAccount(customerId, accountNo2);
		//System.out.println(b+" "+bankingServicesImpl.getCustomerDetails(customerId).getAccountIdxCounter());
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		



