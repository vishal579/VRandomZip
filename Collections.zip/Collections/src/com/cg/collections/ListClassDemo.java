package com.cg.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.cg.collections.beans.Customer;

public class ListClassDemo {
	public static void arrayListClassWork(){
	ArrayList<String> strList=new ArrayList<>();
	strList.add("Vishal");
	strList.add("Sai");
	strList.add("Chowdary");
	strList.add(0,"Jakkampudi");
	System.out.println(strList.toString());
	Collections.sort(strList);
	System.out.println(strList);
	System.out.println(strList.toString());
	System.out.println(strList.size());
	System.out.println(strList.get(3));
	Iterator<String> iterator=strList.iterator();
	while(iterator.hasNext()){
		System.out.println(iterator.next());
	}
	ArrayList<Customer> customerList=new ArrayList<>();
	customerList.add(new Customer(1, "Vishal", "sai"));
	customerList.add(new Customer(2, "Vishu", "JSC"));
	customerList.add(new Customer(3, " J Vishal", "C"));
	Customer customerToBeSearched=new Customer(2, "Vishu", "JSC");
	Collections.sort(customerList);
	
	System.out.println(customerList.toString());
	
	for(Customer customer:customerList)
		System.out.println(customer);
	
	
	}
}
