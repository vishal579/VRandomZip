package com.cg.banking.main;
import com.cg.banking.beans.*;
public class MainClass {

	public static void main(String[] args) {
		Customer customer=new Customer("Vishal", "Sai", "sai@gmail.com", "abc10001", "11-11-1111", 10000, 24800000, 8888888888l, new Address("PUNE", "Maharashtra", "INDIA", 4000011), new Address("HYD", "TG", "INDIA", 500001), new Account[3]);
		Account [] accounts=customer.getAccounts();
		Transaction[] transactions=new Transaction[3];
		accounts[0]=new Account(88888888, 50000, "salary", transactions);
		
		//System.out.println(customer.getHomeAddress().getCity()+" "+accounts[0].getAccountNo()); 
	}
}     
