package com.cg.banking.daoservices;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

//import java.util.Random;
import com.cg.banking.utility.BankingUtility;
import com.cg.banking.utility.BankingUtilityCookies;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	private static HashMap<Integer, Customer> customerMap=new HashMap<>();
	//private static int CUSTOMER_ID_COUNTER=1;
	//private static long ACCOUNT_NO_COUNTER=8000001;
	//private static Random random=new Random();
	@Override
	public int insertCustomer(Customer customer) {
		if(customerMap.containsValue(customer))
			return 0;

		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER);
		customerMap.put(BankingUtility.CUSTOMER_ID_COUNTER++, customer);
		return customer.getCustomerId();

	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtility.ACCOUNT_NO_COUNTER);
		customerMap.get(customerId).getAccountMap().put(BankingUtility.ACCOUNT_NO_COUNTER++, account);
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		customerMap.get(customerId).getAccountMap().replace(BankingUtility.ACCOUNT_NO_COUNTER, account);
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		if(customerMap.get(customerId).getAccountMap().containsKey(account.getAccountNo())==true){
			account.setPinNumber(BankingUtility.random.nextInt(10000));
			return customerMap.get(customerId).getAccountMap().get(account.getAccountNo()).getPinNumber();
		}	
		return 0;	
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo)!=null){
			getCustomer(customerId).getAccountMap().get(accountNo).getTransactionMap().put((BankingUtility.TRANSACTION_ID_COUNTER), transaction);
			transaction.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);

			return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		if(getCustomer(customerId)!=null){
			customerMap.remove(customerId);
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		if(getCustomer(customerId)!=null){
			customerMap.get(customerId).getAccountMap().remove(accountNo);
			return true;
		}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customerMap.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		if(getCustomer(customerId)!=null)
			return customerMap.get(customerId).getAccountMap().get(accountNo);
		return null;
	}

	@Override
	public List<Customer> getCustomers() {

		return new ArrayList(customerMap.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList(customerMap.get(customerId).getAccountMap().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList(customerMap.get(customerId).getAccountMap().get(accountNo).getTransactionMap().values());
	}

	public void doDeSerialization(File fromFile) throws IOException, ClassNotFoundException {
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(fromFile))){
			//ArrayList<Customer> customerList=(ArrayList<Customer>) src.readObject();
			customerMap=(HashMap<Integer, Customer>) src.readObject();
			ArrayList<Integer> customerIdKeySet=new ArrayList<>(customerMap.keySet());
			BankingUtility.CUSTOMER_ID_COUNTER=Collections.max(customerIdKeySet)+1;
			//System.out.println(customerIdKeySet.get(1));
			ArrayList<Long> accountIdKeySet=new ArrayList<>();
			ArrayList<Integer> transactionIdKeySet=new ArrayList<>();
			int i=0;
			while(i<customerMap.size()){
				if(getAccounts(customerIdKeySet.get(i))!=null){
					for(Account account:getAccounts(customerIdKeySet.get(i))){
						accountIdKeySet.add(account.getAccountNo());


						if(getTransactions(customerIdKeySet.get(i),account.getAccountNo())!=null){
							for(Transaction transaction:getTransactions(customerIdKeySet.get(i),account.getAccountNo())){
								transactionIdKeySet.add(transaction.getTransactionId());
							}
						}

					}
					i++;
				}
			}

			BankingUtility.TRANSACTION_ID_COUNTER=Collections.max(transactionIdKeySet)+1;
			BankingUtility.ACCOUNT_NO_COUNTER=Collections.max(accountIdKeySet)+1;

		}
	}

	public  void doSerialization(File toFile) throws FileNotFoundException, IOException {
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(toFile))){
			if(getCustomers().size()==0)
				return;

			dest.writeObject(customerMap);	
			System.out.println(customerMap.toString());
		}
	}
}










//BankingUtilityCookies bankingUtilityCookies=(BankingUtilityCookies) src.readObject();
//for(Customer customer:customerList)
//customerMap.put(customer.getCustomerId(), customer);
//BankingUtility.CUSTOMER_ID_COUNTER=customerList.get(customerList.size()-1).getCustomerId()+1;
//BankingUtility.ACCOUNT_NO_COUNTER;

//System.out.println(customerList.size());
//System.out.println(customer.getCustomerId()+" "+customer);
/*(System.out.println(getCustomers().size());
System.out.println(getCustomers().get(0).getAccountMap().size());
System.out.println(getCustomers().get(1).getAccountMap().size());
//System.out.println(getCustomers().size());
 * for(int i=0;i<customerList.size();i++){
					if(!(customer.getAccountMap().isEmpty()))
				}
				BankingUtility.CUSTOMER_ID_COUNTER=customerList.get(customerList.size()-1).getCustomerId()+1;
			System.out.println(BankingUtility.CUSTOMER_ID_COUNTER);
 */
//System.out.println(customer.getAccountMap().size());
//System.out.println(getCustomers().get(getCustomers().size()-1).getAccountMap().size());
//System.out.println(getCustomers().get(0).getAccountMap().size());