package com.cg.banking.utility;

import java.util.Random;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=1;
	public static long ACCOUNT_NO_COUNTER=8000001;
	public static int TRANSACTION_ID_COUNTER=1001;
	public static Random random=new Random();
}
