package com.cg.services.beans;

public interface MathServices {
	public static final int a=100,b=100;
	int add(int a,int b);
	int sub(int a,int b);
	int mul(int a,int b);
	int div(int a,int b);
}
