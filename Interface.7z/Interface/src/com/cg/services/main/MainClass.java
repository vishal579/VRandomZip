package com.cg.services.main;

import com.cg.services.beans.MathServices;
import com.cg.services.beans.MathServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		MathServices mathServices=new MathServicesImpl();
		System.out.println(mathServices.add(300,200));
		System.out.println(mathServices.a);
	}
}
