package com.cg.payroll.main;
import com.cg.payroll.services.PayrollServices;
//import com.cg.payroll.beans.*;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		PayrollServices payrollServices =new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails("Vishal", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 100000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName() + " " +payrollServices.getAssociateDetails(associateId).getSalary().getGrossSalary()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getNetSalary()+" "+payrollServices.getAssociateDetails(associateId).getSalary().getMonthlyTax());
	}
}








































/*String departmentToBeSearch="IT";
int investmentToBeSearched=100;
Associate associate=searchAssociate(departmentToBeSearch,investmentToBeSearched);
if(associate!=null)
System.out.println(associate.getAssociateId()+" "+associate.getFirstName()+" "+associate.getSalary().getBasicSalary());
else
System.out.println("Not Found");	
}
public static Associate searchAssociate(String department,int investmentToBeSearched){
Associate[] associates=new Associate[3];
associates[0]=new Associate(100, 1000, "Vishal", "Sai", "IT", "Analyst", "ab10000", "abc@gmail.com",new Salary(20000, 12, 12, 3000, 2000, 12, 10, 10, 8, 26000, 24000));
//associates[1]=new Associate(200, 1234, "JVS", "C", "IT", "Software engg", "bg1234", "def@gmail.com");
for (Associate associate : associates) {
	if(associate!=null && associate.getDepartment()==department && associate.getYearlyInvestmentUnder80C()>=investmentToBeSearched&&associate.getSalary().getBasicSalary()>15000)
		return associate;
}
return null;
}*/