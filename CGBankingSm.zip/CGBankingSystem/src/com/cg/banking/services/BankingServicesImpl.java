package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.*;
public class BankingServicesImpl implements BankingServices {
	private BankingDAOServicesImpl daoServicesImpl;
	public BankingServicesImpl() {
		daoServicesImpl=new BankingDAOServicesImpl();
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode)throws BankingServicesDownException{
		
		return daoServicesImpl.insertCustomer(new Customer(firstName, lastName, emailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException,
	InvalidAccountTypeException,
	BankingServicesDownException{
		
		return daoServicesImpl.insertAccount(customerId, new Account(accountType, initBalance));
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount)throws CustomerNotFoundException,
	AccountNotFoundException,BankingServicesDownException, AccountBlockedException {
		
		daoServicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount));
		getAccountDetails(customerId, accountNo).setStatus("Active");
		getAccountAllTransaction(customerId, accountNo)[getAccountDetails(customerId, accountNo).getTransactionIdxCounter()-1].setTransactionType("Deposit");
		this.getAccountDetails(customerId, accountNo).setAccountBalance(this.getAccountDetails(customerId, accountNo).getAccountBalance()+amount);
		return this.getAccountDetails(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)throws InsufficientAmountException,CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException ,AccountBlockedException {
		while(getAccountDetails(customerId, accountNo)!=null&&getAccountDetails(customerId, accountNo).getPinCounter()<3){
		if(getAccountDetails(customerId, accountNo).getPinNumber()==pinNumber&&getAccountDetails(customerId, accountNo).getAccountBalance()>amount){
			daoServicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount));
			this.getAccountDetails(customerId, accountNo).setAccountBalance(this.getAccountDetails(customerId, accountNo).getAccountBalance()-amount);
			getAccountDetails(customerId, accountNo).setPinCounter(0);
			getAccountAllTransaction(customerId, accountNo)[getAccountDetails(customerId, accountNo).getTransactionIdxCounter()-1].setTransactionType("Withdraw");
			return this.getAccountDetails(customerId, accountNo).getAccountBalance();
		}
		getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
		}
		if(	getAccountDetails(customerId, accountNo).getPinCounter()>3){ 
		getAccountDetails(customerId, accountNo).setStatus("Blocked");
		return -1;
		}
		else
			//account not there
			return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException,
	CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException{
			if(getAccountDetails(customerIdFrom, accountNoFrom)!=null&&getAccountDetails(customerIdFrom, accountNoFrom).getAccountBalance()>transferAmount){
				//if(customerIdTo==customerIdFrom){
				withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
				if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber)==-1){
					depositAmount(customerIdFrom, accountNoFrom, transferAmount);
					return false;
				}
				else if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber)==0)
				return false;
				else
				depositAmount(customerIdTo, accountNoTo, transferAmount);
				return true;
			}
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId)throws CustomerNotFoundException,BankingServicesDownException {
		return daoServicesImpl.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)throws 
	CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException {
		
		return daoServicesImpl.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)throws
	CustomerNotFoundException,AccountNotFoundException ,
	BankingServicesDownException {
	
		return daoServicesImpl.generatePin(customerId, this.getAccountDetails(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)throws CustomerNotFoundException,
	AccountNotFoundException,
	InvalidPinNumberException,BankingServicesDownException {
		if(getAccountDetails(customerId, accountNo)==null)
		return false;
		if(getAccountDetails(customerId, accountNo).getPinNumber()==oldPinNumber){
			getAccountDetails(customerId, accountNo).setPinNumber(newPinNumber);
		return true;
		}
		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails()throws BankingServicesDownException {
		
		return daoServicesImpl.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId)throws BankingServicesDownException,CustomerNotFoundException {
		
		return daoServicesImpl.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException {
		
		return daoServicesImpl.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException, AccountBlockedException {
		
		return null;
	}
	public boolean deleteAccount(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException{
		return daoServicesImpl.deleteAccount(customerId, accountNo);
	}

}
