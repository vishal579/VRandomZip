package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetail;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl implements PayrollServices {
	private PayrollDAOServices daoServices;
	public PayrollServicesImpl() {
		daoServices=new PayrollDAOServicesImpl();
	}
	
	@Override
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,String department,String designation,
			String pancard,int yearlyInvestmentUnder80C,double basicSalary,double epf,double companyPf,int accountNumber,
			String bankName,String ifscCode){
	
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetail(accountNumber, bankName, ifscCode)));
	}
	
	@Override
	public int calculateNetSalary(int associateId){
		Associate associate=this.getAssociateDetails(associateId);
		double taxAmount=0.0;
		if(associate!=null){
			associate.getSalary().setPersonalAllowance(0.3*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.2*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity(0.5*associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(associate.getSalary().getPersonalAllowance()+associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			double annualSalary=associate.getSalary().getGrossSalary()*12;
			double taxableSalary=annualSalary;
			double nonTaxableSalary=associate.getYearlyInvestmentUnder80C()+(associate.getSalary().getEpf()*12)+(associate.getSalary().getCompanyPf()*12);
			if(nonTaxableSalary>150000)
				nonTaxableSalary=150000;
			if(taxableSalary<=250000){
				taxAmount=0;
			}	
			else if(taxableSalary>250000 && taxableSalary<=500000){
				taxableSalary=taxableSalary-250000-nonTaxableSalary;
				if(taxableSalary<0)
					taxAmount=0;
				else
				taxAmount=taxableSalary*0.1;	
			}
			else if (taxableSalary>500000 && taxableSalary<=1000000){
				double taxSlab2=(500000-250000-nonTaxableSalary)*0.1;
				taxAmount=(taxableSalary-500000)*0.2+taxSlab2;	
			}
			else if (taxableSalary>1000000){
				double taxSlab2=(500000-250000-nonTaxableSalary)*0.1;
				double taxSlab3=(500000)*0.2;
				taxAmount=(taxableSalary-1000000)*0.3+taxSlab3+taxSlab2;	
			}
			associate.getSalary().setMonthlyTax((float)taxAmount/12);
			associate.getSalary().setNetSalary((float)((annualSalary-taxAmount)/12)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
			return 1 ;
		}
		return 0;
	}
	
	@Override
	public Associate getAssociateDetails(int associateId){
		Associate associate=daoServices.getAssociate(associateId);
		return associate;
	}
	
	@Override
	public Associate[] getAllAssociateDetails(){
		Associate[] associates=daoServices.getAssociates();
		return associates;
	}
}
